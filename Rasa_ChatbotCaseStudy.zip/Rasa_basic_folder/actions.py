from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_core.actions.action import Action
from rasa_core.events import SlotSet
import zomatopy
import json
import smtplib, ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText



class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_restaurant'

	def run(self, dispatcher, tracker, domain):
		#config={ "user_key":"6ce88a5ec1419e335afa1c7f92f4b739"}
		config={ "user_key":"cea1d679322f6d7d50388412756b2b34"}
		zomato = zomatopy.initialize_app(config)
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		price=tracker.get_slot('price')
		
		location_detail=zomato.get_location(loc, 1)
		d1 = json.loads(location_detail)
		#Check for Cities in Tier 1 or 2 else sorry message
		city_id = d1["location_suggestions"][0]["city_id"]
		cityids =[11,4,7,1,6,2,3,5,34,11303,22,25,11343,11382,11384,26,29,11346,12,30,11289,35,11387,11421,11345,11388,11350,11311,11403,11339,21,11337,11374,14,11336,10,11306,11307,11321,11338,11352,11301,23,11401,9,11334,11302,11391,8,20,11295,13,31,11329,11393,36,33,11395,16,11396,11314,40,24,11310,11294,11402,27,11358,11331,11431,11327,11076,38,11298,11368,11316,32,39,11300,28,11372]
		if city_id not in cityids:
			response = "Sorry, We do not operate in this city"
		else:
			print("Inputs : Location ",loc," Cusine ",cuisine," price range ",price)
			price=price.strip()
			price=price.lower()
			print(price+" From user")
			
			lat=d1["location_suggestions"][0]["latitude"]
			lon=d1["location_suggestions"][0]["longitude"]
			cuisines_dict={'chinese':25,'italian':55,'north indian':50,'south indian':85,'American':1,'Mexican': 73}
			results=zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)), 5)
			#print("Query Results: ", results)
			d = json.loads(results)
			#print("Number of results:",d['results_found'])
			response=""
			if d['results_found'] == 0:
				response= "no results"
			else:
				for restaurant in d['restaurants']:
					result_price=restaurant['restaurant']['average_cost_for_two']
					#print("result_price :",result_price)
					if(price=="lesser than Rs. 300" and result_price<300):
						#print("came in first check")
						response=response+ "Found "+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" with rating"+ restaurant['restaurant']['user_rating']['aggregate_rating'] +" \n"
					elif(price=="Rs. 300 to 700" and result_price>300 and result_price<=700):
						#print("came in second check")
						response=response+ "Found "+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" with rating"+ restaurant['restaurant']['user_rating']['aggregate_rating'] +" \n"
					elif(price=="more than 700" and result_price>700):
						#print("came in third check")
						response=response+ "Found "+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" with rating"+ restaurant['restaurant']['user_rating']['aggregate_rating'] +" \n"
					#else:    
					#	response=response+" Found a restaurant but is not in your Budget Range"
				#print("Done with loop")		    
		dispatcher.utter_message("-----"+response)
		return [SlotSet('location',loc)]

class ActionSendEmail(Action):
	def name(self):
		return 'action_sendemail'
		
	def run(self, dispatcher, tracker, domain):
		#config={ "user_key":"6ce88a5ec1419e335afa1c7f92f4b739"}
		config={ "user_key":"cea1d679322f6d7d50388412756b2b34"}
		print("In Email block")


		#Query from zomato for top 10 results
		zomato = zomatopy.initialize_app(config)
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		price=tracker.get_slot('price')
		print("Inputs : Location ",loc," Cusine ",cuisine," price range ",price)
		price=price.strip()
		price=price.lower()
		print(price+" From user")

		
		location_detail=zomato.get_location(loc, 1)
		d1 = json.loads(location_detail)
		lat=d1["location_suggestions"][0]["latitude"]
		lon=d1["location_suggestions"][0]["longitude"]
		#Check for Cities in Tier 1 or 2 else sorry message
		city_id = d1["location_suggestions"][0]["city_id"]
		cityids = [11,4,7,1,6,2,3,5,34,11303,22,25,11343,11382,11384,26,29,11346,12,30,11289,35,11387,11421,11345,11388,11350,11311,11403,11339,21,11337,11374,14,11336,10,11306,11307,11321,11338,11352,11301,23,11401,9,11334,11302,11391,8,20,11295,13,31,11329,11393,36,33,11395,16,11396,11314,40,24,11310,11294,11402,27,11358,11331,11431,11327,11076,38,11298,11368,11316,32,39,11300,28,11372]
		if city_id not in cityids:
			response = "Sorry, We do not operate in this city"
		else:
			cuisines_dict={'chinese':25,'italian':55,'north indian':50,'south indian':85,'American':1,'Mexican': 73}
			results=zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)), 10)
			print("Query Results: ", results)
			d = json.loads(results)
			#print("Number of results:",d['results_found'])
			response="Following are the Restaurant Search Results for Location "+loc+" in Cusine "+ cuisine +"\n\n\n"
			if d['results_found'] == 0:
				response= "no results"
			else:
				for restaurant in d['restaurants']:
					response=response+ ("Found "+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" With Avg Budget for 2 People "+
										str(restaurant['restaurant']['average_cost_for_two'])+
										" with rating "+ restaurant['restaurant']['user_rating']['aggregate_rating']
										+" \n")
			print("Done with loop")
			#print("Resoonse goes like this \n")
			#print(response)
			emailID=tracker.get_slot('email')
			print(emailID)

        	#mailing Code
			port = 587  # For starttls
			smtp_server = "smtp.gmail.com"
			sender_email = "chatbotupgradrestaurant@gmail.com"
			receiver_email = emailID
			password = 'Chatbot@1234'

		    #login to smtp server
			s = smtplib.SMTP(smtp_server, port)
			s.starttls()
			s.login(sender_email, password)

			msg = MIMEMultipart()  
		
			msg['From']="chatbotupgradrestaurant@gmail.com"
			msg['To']=emailID
			msg['Subject']="Mail From Restaurant Search"
		
			message=str(response)
       
	    	# add in the message body
			msg.attach(MIMEText(message, 'plain'))

        	# send the message via the server set up earlier.
			s.send_message(msg)

			print("At end now: Check mail now... ")


		dispatcher.utter_message("Sent an email.")
		return [SlotSet('emailID',loc)]