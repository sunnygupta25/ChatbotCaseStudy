## Generated Story 6271579740611169460
* greet
    - utter_greet
* restaurant_search{"location": "mathura"}
    - slot{"location": "mathura"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_restaurant
    - slot{"location": "mathura"}
    - utter_ask_sendEmail
* utter_give_email
* send_email{"email": "kundra.naveen@gmail.com"}
    - slot{"email": "kundra.naveen@gmail.com"}
    - action_sendemail
    - utter_goodbye


## Generated Story 697692926473808800
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "patna"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "patna"}
    - utter_ask_budget
* restaurant_search{"price": "lesser than rs. 300"}
    - slot{"price": "lesser than rs. 300"}
    - action_restaurant
    - slot{"location": "patna"}
    - utter_ask_sendEmail
* affirm
    - utter_ask_Email_Id
* send_email{"email": "kundra.naveen@gmail.com"}
    - slot{"email": "kundra.naveen@gmail.com"}
    - action_sendemail
    - utter_goodbye


## Generated Story 2490289361757720745
* greet
    - utter_greet
* restaurant_search
    - utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - utter_ask_location
* restaurant_search{"location": "pune"}
    - slot{"location": "pune"}
    - utter_ask_budget
* restaurant_search{"price": "rs. 300 to 700"}
    - slot{"price": "rs. 300 to 700"}
    - action_restaurant
    - slot{"location": "pune"}
    - utter_ask_sendEmail
* affirm
    - utter_ask_Email_Id
* send_email{"email": "abc@yahoo.com"}
    - slot{"email": "abc@yahoo.com"}
    - action_sendemail
    - utter_goodbye


## Generated Story -683423658554120746
* greet
    - utter_greet
* restaurant_search{"price": "More than 700", "cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "More than 700"}
    - utter_ask_location
* restaurant_search{"location": "kozhikode"}
    - slot{"location": "kozhikode"}
    - action_restaurant
    - utter_ask_sendEmail
* affirm
    - utter_ask_Email_Id
* send_email{"email": "kjh@yahoo.com"}
    - slot{"email": "kjh@yahoo.com"}
    - action_sendemail
    - utter_goodbye
    - export


## Generated Story -5846984035316492159
* greet
    - utter_greet
* restaurant_search{"location": "chennai", "cuisine": "american"}
    - slot{"cuisine": "american"}
    - slot{"location": "chennai"}
    - utter_ask_budget
* restaurant_search{"price": "rs. 300 to rs. 700"}
    - slot{"price": "rs. 300 to rs. 700"}
    - action_restaurant
    - slot{"location": "chennai"}
    - utter_ask_sendEmail
* goodbye
    - utter_goodbye
    - export



## Generated Story 4975345543323521094
* greet
    - utter_greet
* utter_ask_cuisine{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_location
* restaurant_search{"location": "pune"}
    - slot{"location": "pune"}
    - action_restaurant
    - slot{"location": "pune"}
    - utter_ask_sendEmail
* affirm
    - utter_ask_Email_Id
* send_email{"email": "kkk@yahoo.com"}
    - slot{"email": "kkk@yahoo.com"}
    - action_sendemail
    - utter_goodbye
    - export

## Generated Story 500467599085550689
* greet
    - utter_greet
* restaurant_search
    - utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - utter_ask_location
* restaurant_search{"location": "pune"}
    - slot{"location": "pune"}
    - utter_ask_budget
* restaurant_search{"price": "Lesser than Rs. 300"}
    - slot{"price": "Lesser than Rs. 300"}
    - action_restaurant
    - slot{"location": "pune"}
    - utter_ask_sendEmail
* affirm
    - utter_ask_Email_Id
* send_email{"email": "hggg@yahoo.com"}
    - slot{"email": "hggg@yahoo.com"}
    - action_sendemail
    - utter_goodbye
    - export
	
	
## Generated Story 7569626314950261297
* greet{"location": "hola"}
    - slot{"location": "hola"}
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bengaluru"}
    - slot{"location": "bengaluru"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"price": "lesser than rs. 300"}
    - slot{"price": "lesser than rs. 300"}
    - action_restaurant
    - utter_ask_sendEmail
* send_email{"email": "sunnygupta25@gmail.com"}
    - slot{"email": "sunnygupta25@gmail.com"}
    - action_sendemail
* affirm{"location": "thanks"}
    - slot{"location": "thanks"}
    - utter_goodbye
    - export

## Generated Story -385319234505051988
* greet{"location": "hola"}
    - slot{"location": "hola"}
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bengaluru"}
    - slot{"location": "bengaluru"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"price": "rs. 300 to 700"}
    - slot{"price": "rs. 300 to 700"}
    - action_restaurant
    - utter_ask_sendEmail
* send_email{"email": "ahbcdj@dkj.com"}
    - slot{"email": "ahbcdj@dkj.com"}
    - action_sendemail
* affirm{"location": "thanks"}
    - slot{"location": "thanks"}
    - utter_goodbye
    - export

## Generated Story -8648759444635478596
* greet{"location": "hola"}
    - slot{"location": "hola"}
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bengaluru"}
    - slot{"location": "bengaluru"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_restaurant
    - utter_ask_sendEmail
* affirm
    - utter_goodbye
    - export

## Generated Story 4652934499155719122
* greet
    - utter_greet
* restaurant_search{"location": "Prayagraj"}
    - slot{"location": "Prayagraj"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - utter_ask_budget
* restaurant_search{"price": "rs. 300 to 700"}
    - slot{"price": "rs. 300 to 700"}
    - action_restaurant
    - utter_ask_sendEmail
* restaurant_search{"location": "xyz@sth.edu"}
    - slot{"location": "xyz@sth.edu"}
    - action_sendemail
    - utter_confirm
* 
* affirm
    - utter_goodbye
    - export

## Generated Story -1276015216758664940
* greet
    - utter_greet
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_budget
* restaurant_search{"price": "lesser than rs. 300"}
    - slot{"price": "lesser than rs. 300"}
    - action_restaurant
    - utter_ask_sendEmail
* send_email{"location": "jddk.2jmd@kdl.co.in"}
    - slot{"location": "jddk.2jmd@kdl.co.in"}
    - utter_ask_sendEmail
* send_email{"email": "jddk.2jmd@kdl.com"}
    - slot{"email": "jddk.2jmd@kdl.com"}
    - utter_confirm
* affirm
    - utter_goodbye
    - export

## Generated Story 4006116273404400553
* greet
    - utter_greet
* send_email{"location": "1"}
    - slot{"location": "1"}
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_budget
* restaurant_search{"price": "lesser than rs. 300"}
    - slot{"price": "lesser than rs. 300"}
    - action_restaurant
    - utter_ask_sendEmail
* send_email{"email": "jddk.2jmd@kdl.com"}
    - slot{"email": "jddk.2jmd@kdl.com"}
    - utter_confirm
* 
* 
* affirm{"location": "thanks"}
    - slot{"location": "thanks"}
    - utter_goodbye
    - export

## Generated Story 4292773998835681766
* greet
    - utter_greet
* restaurant_search{"location": "chandigarh"}
    - slot{"location": "chandigarh"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_budget
* restaurant_search{"price": "rs. 300 to 700"}
    - slot{"price": "rs. 300 to 700"}
    - action_restaurant
    - slot{"location": "chandigarh"}
    - utter_ask_sendEmail
* affirm
    - utter_goodbye
    - export

## Generated Story 4894502098482202381
* greet
    - utter_greet
* restaurant_search{"cuisine": "american", "location": "bangalore", "price": "more than 700"}
    - slot{"cuisine": "american"}
    - slot{"location": "bangalore"}
    - slot{"price": "more than 700"}
    - action_restaurant
    - slot{"location": "bangalore"}
    - utter_ask_sendEmail
* affirm
    - utter_ask_Email_Id
* send_email{"email": "sunnygupta25@gmail.com"}
    - slot{"email": "sunnygupta25@gmail.com"}
    - action_sendemail
    - utter_goodbye
    - export

## Generated Story -5666204543648859940
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mysore"}
    - slot{"location": "mysore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_budget
* restaurant_search{"price": "rs. 300 to 700"}
    - slot{"price": "rs. 300 to 700"}
    - action_restaurant
    - slot{"location": "mysore"}
    - utter_ask_sendEmail
* affirm
    - utter_ask_Email_Id
* send_email{"email": "abcdh24@xgye.co.in"}
    - slot{"email": "abcdh24@xgye.co.in"}
    - action_sendemail
    - utter_confirm
* affirm
    - utter_goodbye
    - export
